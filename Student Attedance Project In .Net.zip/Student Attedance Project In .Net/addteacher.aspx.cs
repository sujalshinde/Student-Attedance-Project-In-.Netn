﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project1
{
    public partial class addteacher : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into Table_3 values (@teacherid,@teachername,@education,@email,@phoneno)", con);
            cmd.Parameters.AddWithValue("@teacherid", txtteacherid.Text);
            cmd.Parameters.AddWithValue("@teachername", teachername.Text);
            cmd.Parameters.AddWithValue("@education", education.Text);
            cmd.Parameters.AddWithValue("@email", email.Text);
            cmd.Parameters.AddWithValue("@phoneno", phoneno.Text);
            


            con.Open();
            cmd.ExecuteNonQuery();


            txtteacherid.Text = "";
            teachername.Text = "";
            education.Text = "";
            email.Text = "";
            phoneno.Text = "";

            Response.Write("<script>alert('Saved..!')</script>");
        }

        protected void Unnamed_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Teacher.aspx");
        }
    }
}