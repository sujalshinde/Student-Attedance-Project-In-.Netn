﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace project1
{
    public partial class facultyoverallattedance : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
       
        }

        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance order by id", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance where class=@class and semester=@semester and date=@date", con);
            cmd.Parameters.AddWithValue("@class", ddlist.Text);
            cmd.Parameters.AddWithValue("@semester", DropList.Text);
            cmd.Parameters.AddWithValue("@date", textdate.Text);

            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);



            ddlist.Text = string.Empty;
            DropList. Text = string.Empty;
            textdate.Text = string.Empty;

            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void gvstudent_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvstudent.EditIndex = e.NewEditIndex;
            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void gvstudent_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvstudent.EditIndex = -1;
            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void gvstudent_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvstudent.Rows[e.RowIndex];
            string status = (row.FindControl("txtstatus") as TextBox).Text;
            


            con.Close();
            SqlCommand cmd = new SqlCommand("Update studentattedance set status='" + status + "' where id='" + gvstudent.DataKeys[e.RowIndex].Value + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            gvstudent.EditIndex = -1;
            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void gvstudent_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void gvstudent_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
    }
}