﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project1
{
    public partial class adminoverallattedance : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance order by id ", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;


        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance where class=@class and semester=@semester and date=@date", con);
            cmd.Parameters.AddWithValue("@class", ddlitem.Text);
            cmd.Parameters.AddWithValue("@semester", DropDownList2.Text);
            cmd.Parameters.AddWithValue("@date", textdate.Text);
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);





            ddlitem.Text = string.Empty;
            DropDownList2.Text = string.Empty;
            textdate.Text = string.Empty;

            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void gvstudent_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void gvstudent_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void gvstudent_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void gvstudent_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
    }
}