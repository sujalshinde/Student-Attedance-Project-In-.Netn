﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project1
{
    public partial class admin1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["Admin"] != null)
            //{
            //    lilogout.Visible = true;
            //    lilogin.Visible = false;
            //    lilogin.Visible = true;
            //}
            //else 
            //{
               
            //    lilogout.Visible = false;
            //    lilogin.Visible = true;
            //    lilogin.Visible = false;

            //}
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("admin.aspx");
        }
    }
}