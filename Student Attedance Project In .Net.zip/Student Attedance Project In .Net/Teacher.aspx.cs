﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project1
{
    public partial class Teacher : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
             if (!IsPostBack)
            {
                gvdata.DataSource = getList();
                gvdata.DataBind();
            }
        }
        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from Table_3 order by srno", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        protected void gvdata_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvdata.Rows[e.RowIndex];
            string teacherid = (row.FindControl("txteteacherid") as TextBox).Text;
            string teachername = (row.FindControl("txtename") as TextBox).Text;
            string education = (row.FindControl("txteeducation") as TextBox).Text;
            string email = (row.FindControl("txteemail") as TextBox).Text;
            string phoneno = (row.FindControl("txtephoneno") as TextBox).Text;

            con.Close();
            SqlCommand cmd = new SqlCommand("Update Table_3 set Teacherid='" + teacherid + "',teachername='" + teachername + "',education='" + education + "',email='" + email + "',phoneno='" + phoneno + "' where srno='" + gvdata.DataKeys[e.RowIndex].Value + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            gvdata.EditIndex = -1;
            gvdata.DataSource = getList();
            gvdata.DataBind();

        }

        protected void gvdata_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("delete from Table_3 where srno='" + gvdata.DataKeys[e.RowIndex].Value + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            gvdata.EditIndex = -1;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

        protected void gvdata_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvdata.EditIndex = e.NewEditIndex;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

        protected void gvdata_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvdata.EditIndex = -1;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            Response.Redirect("addteacher.aspx");
        }
    }
}