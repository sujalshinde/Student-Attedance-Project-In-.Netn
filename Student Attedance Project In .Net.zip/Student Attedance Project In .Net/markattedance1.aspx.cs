﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace project1
{
    public partial class markattedance1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                lblDate.Text = GetCurrentTime().DayOfWeek.ToString() + ", " + GetCurrentTime().ToString("dd-MM-yyyy"); 
                txtDate.Text = GetCurrentTime().ToString("yyyy-MM-dd");
                btnMark.Enabled = false;
                btnDelete.Visible = false;
                gvstudent.DataSource = getAttendancedata();
                gvstudent.DataBind();
            }
        }

      
        protected void generateSheet()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentmaster where status='Active'", con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.HasRows)
            {
                while (sdr.Read())
                {
                    
                    SqlCommand cmdinsert = new SqlCommand("insert into studentattedance values (@id,@date,@name,@email, @password,@class,@semester,@city,@status)", con);
                    cmdinsert.Parameters.AddWithValue("@id", sdr.GetValue(0).ToString());
                    cmdinsert.Parameters.AddWithValue("@date", DateTime.Parse(txtDate.Text));
                    cmdinsert.Parameters.AddWithValue("@name", sdr.GetValue(2).ToString());
                    cmdinsert.Parameters.AddWithValue("@email", sdr.GetValue(3).ToString());
                    cmdinsert.Parameters.AddWithValue("@password", sdr.GetValue(4).ToString());
                    cmdinsert.Parameters.AddWithValue("@class", sdr.GetValue(5).ToString());
                    cmdinsert.Parameters.AddWithValue("@semester", sdr.GetValue(6).ToString());
                    cmdinsert.Parameters.AddWithValue("@city", sdr.GetValue(7).ToString());
                    cmdinsert.Parameters.AddWithValue("@status", "");

                    cmdinsert.ExecuteNonQuery();
                   

                }


            }
            con.Close();
            SqlCommand cmdstatus = new SqlCommand("insert into studentattedancestatus (date,status) values (@date,@status)", con);
            cmdstatus.Parameters.AddWithValue("@date", DateTime.Parse(txtDate.Text));
            
            cmdstatus.Parameters.AddWithValue("@status", "processing");
            con.Open();
            cmdstatus.ExecuteNonQuery();
        }
        protected DateTime GetCurrentTime()
        {
            DateTime serverTime = DateTime.Now;
            DateTime _localTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(serverTime, TimeZoneInfo.Local.Id, "India Standard Time");
            return _localTime;
        }
        protected DataSet getAttendancedata()
        {
            btnMark.Enabled = true;
            btnSubmitFinal.Enabled = true;
            con.Close();
            SqlCommand cmdgetcount = new SqlCommand("Select COUNT(Id) from studentattedance where date=@dt   and status=''", con);
            cmdgetcount.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));
            


            con.Open();
            SqlDataReader sdr = cmdgetcount.ExecuteReader();
            if (sdr.HasRows)
            {
                sdr.Read();
                lbltotalmarked.Text = sdr.GetValue(0).ToString();
            }

            con.Close();
            SqlCommand cmd = new SqlCommand("Select * from studentattedance where date=@dt  order by CAST(Id as int) ASC", con);
            cmd.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));
            //cmd.Parameters.AddWithValue("@subjactstatus", ddlpanal . Text);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(ds);
            con.Close();
            return ds;

        }

        protected void Unnamed_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvstudent.EditRowStyle.BackColor = System.Drawing.Color.Yellow;
            gvstudent.EditIndex = e.NewEditIndex;
            gvstudent.DataSource = getAttendancedata();
            gvstudent.DataBind();
        }

        protected void Unnamed_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvstudent.EditIndex = -1;
            gvstudent.DataSource = getAttendancedata();
            gvstudent.DataBind();
        }

        protected void Unnamed_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvstudent.Rows[e.RowIndex];
            CheckBox chk = (row.FindControl("chkAttendence") as CheckBox);
            Label lbl = (row.FindControl("lblerror") as Label);
            

            if (chk.Checked)
            {
                con.Close();
                SqlCommand cmd = new SqlCommand("Update studentattedance set status='Present' where id='" + gvstudent.DataKeys[e.RowIndex].Value + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                gvstudent.EditIndex = -1;
                gvstudent.DataSource = getAttendancedata();
                gvstudent.DataBind();
            }
            else
            {
                lbl.Text = "Please Mark student as Present";
                return;
            }
        }

        protected void Unnamed_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chekpresent = (e.Row.FindControl("chkAttendence") as CheckBox);
                string status = (e.Row.FindControl("statustoCampare") as Label).Text;
               
                if (status == "P")
                {
                    chekpresent.Checked = true;
                }
                else if (status == "A")
                {
                    chekpresent.Checked = false;
                }
                



                foreach (TableCell cell in e.Row.Cells)
                {
                    if (status == "P")
                    {
                        cell.ForeColor = Color.White;
                        cell.BackColor = Color.Green;
                    }
                   

                }
            }
        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {

            con.Close();
            SqlCommand cmd = new SqlCommand("delete from studentattedance  where date=@dt", con);
            cmd.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));
            con.Open();
            cmd.ExecuteNonQuery();

            con.Close();
            SqlCommand cmd1 = new SqlCommand("delete from studentattedancestatus where date=@dt1", con);
            cmd1.Parameters.AddWithValue("@dt1", DateTime.Parse(txtDate.Text));
            con.Open();
            cmd1.ExecuteNonQuery();
            gvstudent.DataSource = getAttendancedata();
            gvstudent.DataBind();
            lblDate.Text = GetCurrentTime().DayOfWeek.ToString() + ", " + GetCurrentTime().ToString("dd-MM-yyyy");
            txtDate.Text = GetCurrentTime().ToString("yyyy-MM-dd");
            btnMark.Enabled = false;
            btnSubmitFinal.Enabled = false;
            btnDelete.Visible = false;
            this.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", "swal('Attendance sheet deleted successfully...!','','success');", true);
        }
        protected void Unnamed_Click3(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gvstudent.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkAttendance = row.FindControl("chkAttendence") as CheckBox;                   
                    //string ot = (row.FindControl("txtot") as TextBox).Text;
                    string attendanceStatus = chkAttendance.Checked ? "Present" : "Absent";
                    string id = (row.FindControl("studentid") as Label).Text.Trim();
                    if (attendanceStatus == "Present")
                    {
                        //Guid orderId = Guid.NewGuid();

                        con.Close();
                        SqlCommand cmd = new SqlCommand("update studentattedance set   status='P' where date=@dt and id=@id  ", con);
                        cmd.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));
                        cmd.Parameters.AddWithValue("@id", id);
                        
                      




                        con.Open();
                        cmd.ExecuteNonQuery();



                    }
                    else if (attendanceStatus == "Absent")
                    {

                        con.Close();
                        SqlCommand cmd = new SqlCommand("update studentattedance set  status='A' where  date=@dt and id=@id", con);
                        cmd.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));
                        cmd.Parameters.AddWithValue("@id", id);
                        

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }


                }
            }
            this.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", "swal('Attendance Marked Successfully...!','','success');", true);
            gvstudent.DataSource = getAttendancedata();
            gvstudent.DataBind();
        }
        protected void btnSubmitFinal_Click(object sender, EventArgs e)
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("Update studentattedancestatus set status='Submitted' where date=@dt", con);
            cmd.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));
            con.Open();
            cmd.ExecuteNonQuery();
            lblDate.Text = GetCurrentTime().DayOfWeek.ToString() + ", " + GetCurrentTime().ToString("dd-MM-yyyy"); ;
            txtDate.Text = GetCurrentTime().ToString("dd-MM-yyyy");
            gvstudent.DataSource = null;
            gvstudent.DataBind();
            lbltotalmarked.Text = "";
            btnMark.Enabled = false;
            btnSubmitFinal.Enabled = false;
            txtDate.Text = GetCurrentTime().ToString("yyyy-MM-dd");
            this.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", "swal('Attendance Submitted Successfully...!','','success');", true);

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DateTime today = GetCurrentTime().Date;
            DateTime selecteddate = DateTime.Parse(txtDate.Text);

            con.Close();
            SqlCommand chk = new SqlCommand("select * from studentattedancestatus where  date=@dt and status='Processing'", con);
            chk.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));




            con.Open();
            SqlDataReader sdrchk = chk.ExecuteReader();
            if (sdrchk.HasRows)
            {
                btnDelete.Visible = true;
                gvstudent.DataSource = getAttendancedata();
                gvstudent.DataBind();
            }
            else
            {
                con.Close();
                SqlCommand chk1 = new SqlCommand("select * from studentattedancestatus where date=@dt  and status='Submitted'", con);
                chk1.Parameters.AddWithValue("@dt", DateTime.Parse(txtDate.Text));



                con.Open();
                SqlDataReader sdrchk1 = chk1.ExecuteReader();
                if (sdrchk1.HasRows)
                {
                    this.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", "swal('Attendance Report for this Date is Submitted...!','','error');", true);
                    return;
                }
                else
                {
                    generateSheet();
                    gvstudent.DataSource = getAttendancedata();
                    gvstudent.DataBind();
                }
                btnDelete.Visible = true;

            }

        }
    }
    }
