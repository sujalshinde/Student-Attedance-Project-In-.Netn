﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Security.Policy;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace project1
{
    public partial class student : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                gvdata.DataSource = getList();
                gvdata.DataBind();
            }
        }

        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from Table_2 order by srno", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }
        protected void gvdata_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvdata.EditIndex = e.NewEditIndex;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

        protected void gvdata_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvdata.EditIndex = -1;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

        protected void gvdata_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            GridViewRow row = gvdata.Rows[e.RowIndex];
            string RollNo = (row.FindControl("txterollno") as TextBox).Text;
            string studentname = (row.FindControl("txteName") as TextBox).Text;
            string city = (row.FindControl("txteCountry") as TextBox).Text;
            string phoneno = (row.FindControl("txtephoneno") as TextBox).Text;
            string Email = (row.FindControl("email") as TextBox).Text;
            string classroom = (row.FindControl("txteclass") as TextBox).Text;
            


            con.Close();
            SqlCommand cmd = new SqlCommand("Update Table_2 set RollNo='" + RollNo + "',studentname='" + studentname + "', city='" + city + "',phoneno='" + phoneno + "', Email='" + Email + "', classroom='" + classroom + "' where Srno='" + gvdata.DataKeys[e.RowIndex].Value + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            gvdata.EditIndex = -1;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

        protected void gvdata_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("delete from Table_2  where srno='" + gvdata.DataKeys[e.RowIndex].Value + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            gvdata.EditIndex = -1;
            gvdata.DataSource = getList();
            gvdata.DataBind();
        }

       

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            {

                Response.Redirect("addstudent.aspx");
            }
        }
    }
}

