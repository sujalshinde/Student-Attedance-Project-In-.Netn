﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Xml.Linq;

namespace project1
{
    public partial class studentattedance : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            

                
            
        }



        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance where status='P' ", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;

           
        }


        protected void Unnamed_Click4(object sender, EventArgs e)
        {


            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance where class=@class and semester=@semester and date=@date", con);
            cmd.Parameters.AddWithValue("@class", ddlpanal.Text);
            cmd.Parameters.AddWithValue("@semester", DropDownList1.Text);
            cmd.Parameters.AddWithValue("@date", txtdate.Text);
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            

           
           
            ddlpanal.Text = string.Empty;
            DropDownList1.Text = string.Empty;
            txtdate.Text = string.Empty;

            gvstudent.DataSource = getList();
            gvstudent.DataBind();

        }

        protected void gvstudent_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void gvstudent_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void gvstudent_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void gvstudent_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
    }
}

