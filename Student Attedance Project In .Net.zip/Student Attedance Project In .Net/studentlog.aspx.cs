﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project1
{
    public partial class studentlog : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {


        }
        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance order by id ", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }


        protected void Unnamed_Click(object sender, EventArgs e)
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance where Email=@email and Password=@password", con);
            cmd.Parameters.AddWithValue("@email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@password", txtPassword.Text);
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);


            gvstudent.DataSource = ds;
            gvstudent.DataBind();
            txtEmail.Text = string.Empty;
            txtPassword.Text = string.Empty;
           




        }

        protected void gvstudent_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void gvstudent_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void gvstudent_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void gvstudent_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
    }

}
