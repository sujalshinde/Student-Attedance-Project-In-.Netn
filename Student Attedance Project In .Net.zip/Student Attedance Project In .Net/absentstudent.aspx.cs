﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace project1
{
    public partial class absentstudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gvstudent.DataSource = getList();
                gvstudent.DataBind();
            }
        }

        protected DataSet getList()
        {
            con.Close();
            SqlCommand cmd = new SqlCommand("select * from studentattedance where status ='A'", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        protected void gvstudent_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvstudent.EditIndex = e.NewEditIndex;
            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void Unnamed_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvstudent.EditIndex = -1;
            gvstudent.DataSource = getList();
            gvstudent.DataBind();
        }

        protected void Unnamed_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void Unnamed_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {

        }

        protected void Unnamed_Click1(object sender, EventArgs e)
        {
            this.ClientScript.RegisterStartupScript(this.GetType(), "SweetAlert", "swal('Send Mail Successfully...!','','success');", true);

        }
    }
}
