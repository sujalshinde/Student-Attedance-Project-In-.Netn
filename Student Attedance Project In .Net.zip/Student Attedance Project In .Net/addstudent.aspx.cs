﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace project1
{
    public partial class addstudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into Table_2 values (@RollNo,@studentname,@city,@phoneno,@Email,@class)", con);
            cmd.Parameters.AddWithValue("@RollNo", txtRollNo.Text);
            cmd.Parameters.AddWithValue("@studentname", Studentname.Text);
            cmd.Parameters.AddWithValue("@city", city.Text);
            cmd.Parameters.AddWithValue("@phoneno", phoneno.Text);
            cmd.Parameters.AddWithValue("@Email", email.Text);
            cmd.Parameters.AddWithValue("@class", ddlCity.Text);


            con.Open();
            cmd.ExecuteNonQuery();


            txtRollNo.Text = "";
            Studentname.Text = "";
            city.Text = "";
            phoneno.Text = "";
            email.Text = "";
            ddlCity.Text = "";
           
            Response.Write("<script>alert('Saved..!')</script>");
        }
    }
}                           